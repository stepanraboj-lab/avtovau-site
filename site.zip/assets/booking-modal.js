const bookingDialog = document.querySelector('#booking-dialog');
const bookingContacts = document.querySelector('.contact-options--booking');

if (bookingDialog && bookingContacts) {
  const panel = bookingDialog.querySelector('.booking-dialog__panel');
  const closeButton = bookingDialog.querySelector('.booking-dialog__close');
  const contacts = bookingContacts.cloneNode(true);
  contacts.classList.remove('contact-options--booking');
  contacts.querySelector('.contact-options__title').remove();
  panel.append(contacts);

  let opener;
  let startedOutside = false;

  for (const button of document.querySelectorAll('.booking-trigger')) {
    button.addEventListener('click', () => {
      opener = button;
      startedOutside = false;
      bookingDialog.showModal();
      document.documentElement.classList.add('booking-open');
      closeButton.focus({preventScroll: true});
    });
  }

  closeButton.addEventListener('click', () => bookingDialog.close());
  bookingDialog.addEventListener('pointerdown', event => {
    startedOutside = event.target === bookingDialog;
  });
  bookingDialog.addEventListener('click', event => {
    if (startedOutside && event.target === bookingDialog) bookingDialog.close();
    startedOutside = false;
  });
  bookingDialog.addEventListener('close', () => {
    document.documentElement.classList.remove('booking-open');
    opener?.focus({preventScroll: true});
  });
}
